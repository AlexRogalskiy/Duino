#ifndef TROYKAMQ_H_
#define TROYKAMQ_H_

#include "MQ2.h"
#include "MQ3.h"
#include "MQ4.h"
#include "MQ5.h"
#include "MQ6.h"
#include "MQ7.h"
#include "MQ8.h"
#include "MQ9.h"

#endif  // TROYKAMQ_H_